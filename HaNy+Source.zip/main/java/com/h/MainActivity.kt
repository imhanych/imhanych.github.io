package com.h

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.widget.AppCompatEditText
import androidx.lifecycle.lifecycleScope
import com.google.android.recaptcha.Recaptcha
import com.google.android.recaptcha.RecaptchaAction
import com.google.android.recaptcha.RecaptchaClient
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.Objects
import java.util.Timer
import java.util.TimerTask
import kotlin.concurrent.fixedRateTimer
import kotlin.concurrent.timer

class MainActivity : AppCompatActivity() {

    private lateinit var recaptchaClient: RecaptchaClient
    private lateinit var userInputEditText: AppCompatEditText
    private lateinit var apikey: AppCompatEditText
    private lateinit var intervaal: AppCompatEditText
    private var myInterval: Timer? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        userInputEditText = findViewById(R.id.host_url)
        apikey = findViewById(R.id.api_key)
        intervaal = findViewById(R.id.interval)
        findViewById<View>(R.id.btn_login).isEnabled = false
        findViewById<View>(R.id.btn_login).setBackgroundColor(android.graphics.Color.parseColor("#b6b6b6"))
        findViewById<View>(R.id.btn_login).setOnClickListener { doloop() }
        findViewById<View>(R.id.init).setOnClickListener {initializeRecaptchaClient()}
        findViewById<View>(R.id.stopper).setOnClickListener {gostop()}
    }

    private fun doloop(){
        val inter = intervaal.text.toString()
        if (inter==""){
            executeLoginAction()
        } else {
            val period = inter.toInt()
            myInterval = fixedRateTimer("myInterval", false, 0L, period.toLong()) {
                executeLoginAction()
            }
        }
    }

    private fun gostop(){
        myInterval?.cancel()
        myInterval = null
    }


    private fun initializeRecaptchaClient() {
        lifecycleScope.launch {
            Recaptcha.getClient(application, apikey.text.toString())
                .onSuccess { client ->
                    recaptchaClient = client
                    findViewById<View>(R.id.btn_login).isEnabled = true
                    findViewById<View>(R.id.btn_login).setBackgroundColor(android.graphics.Color.parseColor("#009307"))
                    findViewById<View>(R.id.init).isEnabled = false
                    findViewById<View>(R.id.init).setBackgroundColor(android.graphics.Color.parseColor("#b6b6b6"))
                }
                .onFailure { exception ->
                    // Handle communication errors ...
                    // See "Handle communication errors" section
                }
        }
    }

    private fun executeLoginAction() {
        lifecycleScope.launch {
            recaptchaClient
                .execute(RecaptchaAction.LOGIN)
                .onSuccess { token ->
                    GlobalScope.launch(Dispatchers.IO) {
                        val url = userInputEditText.text.toString()
                        val requestBody = "{\"cap\": \"$token\"}" // Your JSON request body

                        // Make the POST request
                        val response = makePostRequest(url, requestBody)

                        // Now you can update the UI or perform any other action with the response
                        runOnUiThread {
                            // Update UI or perform other actions here
                            println("Response: $response")
                        }
                    }
                    showToast(applicationContext, "Success")
                }
                .onFailure { exception ->
                    // Handle communication errors ...
                    // See "Handle communication errors" section
                }
        }
    }



    suspend fun makePostRequest(url: String, requestBody: String): String {
        val client = OkHttpClient()

        // Define the media type for the request body (in this example, JSON)
        val mediaType = "application/json; charset=utf-8".toMediaType()

        // Create the request body
        val body = requestBody.toRequestBody(mediaType)

        // Create the POST request
        val request = Request.Builder()
            .url(url)
            .post(body)
            .build()

        // Execute the request and get the response
        val response = client.newCall(request).execute()

        // Get the response body as a string
        return response.body?.string() ?: ""
    }

    fun showToast(context: Context, message: String, duration: Int = Toast.LENGTH_SHORT) {
        Toast.makeText(context, message, duration).show()
    }
}


